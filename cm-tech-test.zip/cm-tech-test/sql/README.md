# SQL Test README

## Database Compatibility

This SQL solution has been tested on: SQL Server 2019
