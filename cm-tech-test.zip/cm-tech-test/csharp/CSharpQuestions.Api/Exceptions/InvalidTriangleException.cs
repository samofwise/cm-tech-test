namespace CSharpQuestions.Api.Exceptions;
public class InvalidTriangleException(string message) : Exception(message)
{
}
