namespace CSharpQuestions.Api.Models;
public class Link
{
  public required string Url { get; set; }
  public bool IsValid { get; set; }
}